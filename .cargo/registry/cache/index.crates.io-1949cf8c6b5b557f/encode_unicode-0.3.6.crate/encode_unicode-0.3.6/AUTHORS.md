# The encode_unicode Developers

* Torbjørn Birch Moltu
* Aljoscha Meyer
