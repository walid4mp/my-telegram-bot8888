# zerofrom [![crates.io](https://img.shields.io/crates/v/zerofrom)](https://crates.io/crates/zerofrom)

<!-- cargo-rdme start -->

This crate provides [`ZeroFrom`], a trait for converting types in a zero-copy way.

See the documentation of [`ZeroFrom`] for more details.

<!-- cargo-rdme end -->

## More Information

For more information on development, authorship, contributing etc. please visit [`ICU4X home page`](https://github.com/unicode-org/icu4x).
