use indoc::indoc;

fn main() {
    indoc!(fail);
}
