test.png: https://commons.wikimedia.org/wiki/File:PNG-Gradient.png
test.jpg: https://commons.wikimedia.org/wiki/File:JPEG_example_JPG_RIP_001.jpg
test.pdf: http://brendanzagaeski.appspot.com/0004.html
