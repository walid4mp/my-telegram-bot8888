//! # Example: hostname-like CLI (Builder API)
//!
//! ```rust
#![doc = include_str!("../../examples/multicall-hostname.rs")]
//! ```
//!
#![doc = include_str!("../../examples/multicall-hostname.md")]
