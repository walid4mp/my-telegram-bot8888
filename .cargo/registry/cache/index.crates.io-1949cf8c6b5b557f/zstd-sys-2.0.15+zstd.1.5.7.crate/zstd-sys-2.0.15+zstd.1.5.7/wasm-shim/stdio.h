#include <stddef.h>

#ifndef	_STDIO_H
#define	_STDIO_H	1

#define fprintf(expr, ...)
#define fflush(expr)

#endif // _STDIO_H

