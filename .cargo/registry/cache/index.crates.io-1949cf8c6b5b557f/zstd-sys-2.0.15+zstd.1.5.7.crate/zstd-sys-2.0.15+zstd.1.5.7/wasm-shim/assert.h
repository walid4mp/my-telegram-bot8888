#ifndef _ASSERT_H
#define _ASSERT_H

#define assert(expr)

#endif // _ASSERT_H
