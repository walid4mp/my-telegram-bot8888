#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif // __cplusplus

extern char MUT_GLOBAL_ARRAY[128];

extern const char CONST_GLOBAL_ARRAY[128];

#ifdef __cplusplus
}  // extern "C"
#endif  // __cplusplus
