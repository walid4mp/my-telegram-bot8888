#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

struct Foo {

};

void extra_debug_fn(void);

void cbindgen(void);

void root(struct Foo a);
