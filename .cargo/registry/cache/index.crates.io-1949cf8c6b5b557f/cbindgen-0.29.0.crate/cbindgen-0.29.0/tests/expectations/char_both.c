#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

typedef struct Foo {
  uint32_t a;
} Foo;

void root(struct Foo a);
