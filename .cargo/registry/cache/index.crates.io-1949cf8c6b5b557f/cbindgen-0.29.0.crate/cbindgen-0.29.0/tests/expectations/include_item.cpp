#include <cstdarg>
#include <cstdint>
#include <cstdlib>
#include <ostream>
#include <new>

struct A {
  int32_t x;
  float y;
};

struct B {
  A data;
};
