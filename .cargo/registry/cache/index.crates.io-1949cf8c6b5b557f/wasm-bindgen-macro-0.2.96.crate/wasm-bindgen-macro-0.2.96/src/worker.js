// This file is needed for the doctest of `crate::link_to`.
